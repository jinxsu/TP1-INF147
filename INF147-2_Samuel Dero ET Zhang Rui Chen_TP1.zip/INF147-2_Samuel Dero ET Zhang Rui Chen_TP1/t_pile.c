/* T_PILE.C
   Module t_pile qui permettra d'impl�menter des op�rations de bases
   sur une pile d'entiers.

   Auteur  : Zhang Rui Chen et Samuel Dero
   Version : Copyright H2026
*/
#include <stdio.h>
#include <stdlib.h>
#include "t_pile.h"

/* Le constructeur re�oit une capacit� maximale d'�l�ments "taille"
retourne une pile initialis�e � vide de cette taille. */
t_pile init_pile(unsigned int taille)
{
	return (t_pile) {(int*)malloc(taille*sizeof(int)), -1, taille };
	
}

/* Fonction-destructeur qui va lib�rer le tableau dynamique de la pile.
Cette pile ne devra plus �tre utilis� avant d�avoir �t� r�initialis�e. */
void liberer_pile(t_pile* pile)
{
	free(pile->items);
	pile->items = NULL;
	pile->sommet = -1;
	pile->taille = 0;
	
}

/* Obtenir le nombre d'�l�ments actuellement dans la pile re�ue en param�tre. */
unsigned int get_nb_elements(const t_pile* pile)
{
	return pile->sommet + 1;
}

/* Obtenir la capacit� maximale de la pile re�ue en param�tre. */
unsigned int get_max_pile(const t_pile* pile)
{
	return pile->taille;
}

/* Obtenir une valeur actuellement dans la pile.
On re�oit trois param�tre : le pointeur d'une pile,
la position voulue (elle doit �tre valide, de 0 � p->sommet)
et la r�f�rence ou copier l'�l�ment � la position re�ue.
On retourne 1 si la position re�ue est valide, et 0 sinon. */
int get_element(const t_pile* pile, unsigned int position, t_element* elem)
{
	if(position > pile->sommet || position < 0) {
		return 0;
	}
	*elem = pile->items[position];
	return 1;
		
	
}

/* Confirme la pr�sence de la valeur "elem" dans la pile.
On retourne 0 si la valeur "elem" n'y est pas et 1 si elle est pr�sente. */
int present_pile(const t_pile* pile, t_element elem)
{
	for(int i=0; i < pile->sommet; i++) {
		if(pile->items[i] == elem) {
			return 1;
		}
		
	}
	return 0;
}

/* Extraction de la pile (pop):
On re�oit le pointeur d'une pile existante et la r�f�rence ou copier l'�l�ment extrait.
Retour de 0 si la pile est vide -- seul cas possible. Sinon 1 (extraction r�ussie). */
int pop_pile(t_pile* p, t_element* dest)
{
	if(p->sommet == -1) {
		return 0;
	}
	*dest = p->items[p->sommet];
	p->sommet--;
	return 1;
	
}

/* Insertion dans la pile (push):
On re�oit le pointeur d'une pile et la valeur "src" � ins�rer.
Retour de 0 si la pile est pleine -- seul cas possible. Sinon 1 (insertion r�ussie). */
int push_pile(t_pile* p, t_element src)
{
	if(p->sommet==p->taille-1) {
		return 0;
	}
	p->sommet++;
	p->items[p->sommet] = src;
	return 1;	
	
}



