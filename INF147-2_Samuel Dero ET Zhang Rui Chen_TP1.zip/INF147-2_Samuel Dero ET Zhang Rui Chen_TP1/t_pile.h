#pragma once
/* T_PILE.H
   Module t_pile qui permettra d'impl�menter des op�rations de bases
   sur une pile d'entiers.

   Auteur  : Pierre B�lisle
   R�vision: �ric Th�
   Version : Copyright H2026
*/
#ifndef T_PILE_H
#define T_PILE_H

typedef int t_element;   //modifier cette d�claration pour avoir une pile d'un autre type

/* le type-enregistrement pour une pile */
typedef struct {
	t_element* items;	//tableau dynamique des �l�ments de la pile
	int sommet;			//position du sommet (top) de la pile. sera == -1 lorsque vide 
	int taille;			//taille maximale du tableau dynamique
} t_pile;


/* Voici le constructeur: */

/* Le constructeur re�oit une capacit� maximale d'�l�ments "taille"
retourne une pile initialis�e � vide de cette taille. */
t_pile init_pile(unsigned int taille);


/* Voici le destructeur: */

/* Fonction-destructeur qui va lib�rer le tableau dynamique de la pile.
Cette pile ne devra plus �tre utilis� avant d�avoir �t� r�initialis�e. */
void liberer_pile(t_pile* pile);


/* Voici quatre fonctions informatrices de l��tat de la pile : */

/* Obtenir le nombre d'�l�ments actuellement dans la pile re�ue en param�tre. */
unsigned int get_nb_elements(const t_pile* pile);

/* Obtenir la capacit� maximale de la pile re�ue en param�tre. */
unsigned int get_max_pile(const t_pile* pile);

/* Obtenir une valeur actuellement dans la pile.
On re�oit trois param�tre : le pointeur d'une pile,
la position voulue (elle doit �tre valide, de 0 � p->sommet)
et la r�f�rence ou copier l'�l�ment � la position re�ue.
On retourne 1 si la position re�ue est valide, et 0 sinon. */
int get_element(const t_pile* pile, unsigned int position, t_element* elem);

/* Confirme la pr�sence de la valeur "elem" dans la pile.
On retourne 0 si la valeur "elem" n'y est pas et 1 si elle est pr�sente. */
int present_pile(const t_pile* pile, t_element elem);


/* Voici les deux fonctions mutatrices de l��tat de la pile : */

/* Extraction de la pile (pop):
On re�oit le pointeur d'une pile existante et la r�f�rence ou copier l'�l�ment extrait.
Retour de 0 si la pile est vide -- seul cas possible. Sinon 1 (extraction r�ussie). */
int pop_pile(t_pile* p, t_element* dest);

/* Insertion dans la pile (push):
On re�oit le pointeur d'une pile et la valeur "src" � ins�rer.
Retour de 0 si la pile est pleine -- seul cas possible. Sinon 1 (insertion r�ussie). */
int push_pile(t_pile* p, t_element src);

#endif // T_PILE__

