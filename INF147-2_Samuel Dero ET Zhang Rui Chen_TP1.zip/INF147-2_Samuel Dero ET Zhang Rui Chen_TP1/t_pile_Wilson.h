#pragma once
/* T_PILE_WILSON.H
   Extension du module t_pile qui permettra d'impl�menter l'algorithme
   de Wilson pour g�n�ner un labyrinthe.

   Auteur  : Pierre B�lisle
   R�vision: �ric Th�
   Version : Copyright H2026
*/

#ifndef T_PILE_WILSON__
#define T_PILE_WILSON__

#include "t_pile.h"

typedef t_pile* t_pile_Wilson;    //le nouveau type-pointeur � une pile de Wilson

/* Fonctions informatrices de l��tat de la pile : */

/* Retourne la position de "elem" dans la pile ou -1 si absent. */
int obtenir_pos(const t_pile_Wilson pile, t_element elem);

/* Concat�nation des �l�ments d�une pile sur une autre pile.
On re�oit une pile existante et le poinetur d'une autre pile "p_src" dont le
contenu sera empil�e sur la premi�re en respectant l'ordre LIFO.
Retour de 1 si la concat�nation a �t� faite enti�rement
et de 0 si la seconde pile ne peut �tre totalement empil�e dans la premi�re
par manque de place, -- seul cas possible. */
int concatener_piles(t_pile_Wilson p_dest, const t_pile_Wilson p_src);

/* La pile est partiellement vid�e sans r�cup�ration des objets �limin�s.
Sa taille maximale restera la m�me, c'est le nombre d'�l�ments qui sera modifi�.
On re�oit une pile existante et le nombre d��l�ments � y conserver.
Retour de 1 si la pile a effectivement �t� tronqu�e. Sinon 0 (pas assez d'�l�ments). */
int tronquer_pile(t_pile_Wilson pile, unsigned int nb_elements);


#endif // T_PILE__
